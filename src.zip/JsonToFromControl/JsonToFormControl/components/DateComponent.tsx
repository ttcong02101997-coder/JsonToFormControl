import {
    Input,
    makeStyles,
    tokens,
} from "@fluentui/react-components";
import React, {
    useEffect,
    useMemo,
    useRef,
    useState,
} from "react";
import { FieldComponentProps } from "../ShareLibs/Models";
import { IconLock } from "../ShareLibs/Icons";

const useStyles = makeStyles({
    styleOverField: {
        padding: "3px 0",
    },

    wrapper: {
        position: "relative",
        width: "100%",
    },

    styleInput: {
        background: "rgba(0, 0, 0, 0.06)",
        width: "100%",
        border: "none",
        boxSizing: "border-box",

        "& input": {
            paddingRight: "36px",
        },
    },

    calendarButton: {
        position: "absolute",
        right: "6px",
        top: "50%",
        transform: "translateY(-50%)",
        width: "28px",
        height: "28px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        border: "none",
        background: "transparent",
        cursor: "pointer",
        color: tokens.colorNeutralForeground3,
        borderRadius: "2px",

        ":hover": {
            background: tokens.colorNeutralBackground3Hover,
            color: tokens.colorNeutralForeground1,
        },
    },

    calendarIcon: {
        width: "16px",
        height: "16px",
    },

    styleInputReadOnly: {
        background: "rgba(0, 0, 0, 0.06)",
        width: "100%",
        border: "none",

        ":focus-within::after": {
            borderBottomColor: "#ccc",
        },
    },

    calendarPopup: {
        position: "fixed",
        zIndex: 999999,

        width: "280px",

        backgroundColor: "#ffffff",

        border: "1px solid #d1d1d1",
        borderRadius: "2px",

        boxShadow:
            "0 4px 8px rgba(0,0,0,.14), 0 8px 16px rgba(0,0,0,.14)",

        padding: "12px",

        boxSizing: "border-box",
    },

    calendarHeader: {
        display: "flex",
        alignItems: "center",
        height: "32px",
        marginBottom: "8px",
    },

    navigationButton: {
        width: "32px",
        height: "32px",
        padding: 0,
        border: "none",
        background: "transparent",
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: "22px",
        color: tokens.colorNeutralForeground2,
        borderRadius: "2px",

        ":hover": {
            background: tokens.colorNeutralBackground3Hover,
        },
    },

    monthTitle: {
        flex: 1,
        textAlign: "center",
        fontSize: "14px",
        fontWeight: 600,
        color: tokens.colorNeutralForeground1,
    },

    weekHeader: {
        display: "grid",
        gridTemplateColumns: "repeat(7, 1fr)",
        marginBottom: "2px",
    },

    weekDay: {
        height: "28px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: "11px",
        fontWeight: 600,
        color: tokens.colorNeutralForeground3,
    },

    daysGrid: {
        display: "grid",
        gridTemplateColumns: "repeat(7, 1fr)",
    },

    dayButton: {
        width: "32px",
        height: "32px",
        padding: 0,
        margin: "1px",
        border: "none",
        borderRadius: "2px",
        background: "transparent",
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: "12px",
        color: tokens.colorNeutralForeground1,

        ":hover": {
            background: tokens.colorNeutralBackground3Hover,
        },
    },

    otherMonthDay: {
        color: tokens.colorNeutralForeground4,
    },

    todayDay: {
        boxShadow: `inset 0 0 0 1px ${tokens.colorBrandForeground1}`,
        fontWeight: 600,
    },

    selectedDay: {
        backgroundColor: tokens.colorBrandBackground,
        color: tokens.colorNeutralForegroundOnBrand,

        ":hover": {
            backgroundColor: tokens.colorBrandBackgroundHover,
        },
    },

    calendarFooter: {
        display: "flex",
        justifyContent: "flex-end",
        marginTop: "8px",
        paddingTop: "8px",
        borderTop: "1px solid #edebe9",
    },

    todayButton: {
        border: "none",
        background: "transparent",
        color: tokens.colorBrandForeground1,
        cursor: "pointer",
        fontSize: "12px",
        padding: "5px 8px",
        borderRadius: "2px",

        ":hover": {
            background: tokens.colorNeutralBackground3Hover,
        },
    },
});

interface CalendarDay {
    date: Date;
    currentMonth: boolean;
}

const normalizeDate = (value: unknown): string => {
    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {
        return "";
    }

    if (
        typeof value === "object" &&
        value !== null &&
        "value" in value
    ) {
        return normalizeDate(
            (value as { value: unknown }).value
        );
    }

    if (value instanceof Date) {
        if (Number.isNaN(value.getTime())) {
            return "";
        }

        return toIsoDate(value);
    }

    if (typeof value === "string") {
        const match =
            /^(\d{4})-(\d{2})-(\d{2})/.exec(
                value.trim()
            );

        if (match) {
            return `${match[1]}-${match[2]}-${match[3]}`;
        }
    }

    return "";
};

const toIsoDate = (date: Date): string => {
    const year = date.getFullYear();

    const month = String(
        date.getMonth() + 1
    ).padStart(2, "0");

    const day = String(
        date.getDate()
    ).padStart(2, "0");

    return `${year}-${month}-${day}`;
};

const parseIsoDate = (
    value: string
): Date | null => {
    const match =
        /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);

    if (!match) {
        return null;
    }

    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);

    const result = new Date(
        year,
        month - 1,
        day
    );

    if (
        result.getFullYear() !== year ||
        result.getMonth() !== month - 1 ||
        result.getDate() !== day
    ) {
        return null;
    }

    return result;
};

const formatDateValue = (
    value: string,
    format: string
): string => {
    const match =
        /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);

    if (!match) {
        return "";
    }

    const year = match[1];
    const month = match[2];
    const day = match[3];

    const replacements: Record<string, string> = {
        yyyy: year,
        yy: year.substring(2),
        MM: month,
        M: String(Number(month)),
        dd: day,
        d: String(Number(day)),
    };

    return format.replace(
        /yyyy|yy|MM|M|dd|d/g,
        (token) => replacements[token] ?? token
    );
};

const parseInputDate = (
    value: string,
    format: string
): string => {
    if (!value.trim()) {
        return "";
    }

    const tokens =
        format.match(/yyyy|yy|MM|M|dd|d/g);

    if (!tokens || tokens.length !== 3) {
        return "";
    }

    const parts = value
        .trim()
        .split(/[/.\- ]+/);

    if (parts.length !== 3) {
        return "";
    }

    let year = 0;
    let month = 0;
    let day = 0;

    for (let i = 0; i < tokens.length; i++) {
        const number = Number(parts[i]);

        if (!Number.isInteger(number)) {
            return "";
        }

        switch (tokens[i]) {
            case "yyyy":
                year = number;
                break;

            case "yy":
                year = 2000 + number;
                break;

            case "MM":
            case "M":
                month = number;
                break;

            case "dd":
            case "d":
                day = number;
                break;
        }
    }

    if (
        year < 1000 ||
        month < 1 ||
        month > 12 ||
        day < 1 ||
        day > 31
    ) {
        return "";
    }

    const date = new Date(
        year,
        month - 1,
        day
    );

    if (
        date.getFullYear() !== year ||
        date.getMonth() !== month - 1 ||
        date.getDate() !== day
    ) {
        return "";
    }

    return toIsoDate(date);
};

const buildCalendarDays = (
    year: number,
    month: number
): CalendarDay[] => {
    const firstDay = new Date(
        year,
        month,
        1
    ).getDay();

    const daysInMonth = new Date(
        year,
        month + 1,
        0
    ).getDate();

    const previousMonthDays = new Date(
        year,
        month,
        0
    ).getDate();

    const days: CalendarDay[] = [];

    for (
        let i = firstDay - 1;
        i >= 0;
        i--
    ) {
        days.push({
            date: new Date(
                year,
                month - 1,
                previousMonthDays - i
            ),
            currentMonth: false,
        });
    }

    for (
        let day = 1;
        day <= daysInMonth;
        day++
    ) {
        days.push({
            date: new Date(
                year,
                month,
                day
            ),
            currentMonth: true,
        });
    }

    let nextDay = 1;

    while (days.length < 42) {
        days.push({
            date: new Date(
                year,
                month + 1,
                nextDay
            ),
            currentMonth: false,
        });

        nextDay++;
    }

    return days;
};

const sameDate = (
    first: Date | null,
    second: Date | null
): boolean => {
    if (!first || !second) {
        return false;
    }

    return (
        first.getFullYear() ===
        second.getFullYear() &&
        first.getMonth() ===
        second.getMonth() &&
        first.getDate() ===
        second.getDate()
    );
};

const DateComponent = ({
    setFieldValue,
    value,
    isDisable,
    isRequired,
    label,
    logicalName,
    fieldValue,
    isValid,
    dateFormat,
}: FieldComponentProps) => {
    const styles = useStyles();

    const trimmedFormat = dateFormat?.trim();
    const format = trimmedFormat === undefined || trimmedFormat === ""
        ? "dd/MM/yyyy"
        : trimmedFormat;

    const [date, setDate] = useState<string>(
        () => normalizeDate(value)
    );

    const [inputValue, setInputValue] =
        useState<string>("");

    const [isCalendarOpen, setIsCalendarOpen] =
        useState(false);

    const [calendarMonth, setCalendarMonth] =
        useState<Date>(() => {
            const normalized =
                normalizeDate(value);

            return (
                parseIsoDate(normalized) ??
                new Date()
            );
        });

    const [inputError, setInputError] =
        useState("");

    const wrapperRef =
        useRef<HTMLDivElement>(null);

    const popupRef =
        useRef<HTMLDivElement>(null);

    const calendarButtonRef =
        useRef<HTMLButtonElement>(null);

    useEffect(() => {
        const normalized =
            normalizeDate(value);

        setDate(normalized);

        setInputValue(
            normalized
                ? formatDateValue(
                    normalized,
                    format
                )
                : ""
        );

        const parsed =
            parseIsoDate(normalized);

        if (parsed) {
            setCalendarMonth(
                new Date(
                    parsed.getFullYear(),
                    parsed.getMonth(),
                    1
                )
            );
        }
    }, [value, format]);

    /**
     * Mở calendar.
     */
    const openCalendar = (): void => {
        if (isDisable) {
            return;
        }

        const selected =
            parseIsoDate(date);

        if (selected) {
            setCalendarMonth(
                new Date(
                    selected.getFullYear(),
                    selected.getMonth(),
                    1
                )
            );
        } else {
            const today = new Date();

            setCalendarMonth(
                new Date(
                    today.getFullYear(),
                    today.getMonth(),
                    1
                )
            );
        }

        setIsCalendarOpen(true);
    };

    /**
     * Click outside.
     */
    useEffect(() => {
        if (!isCalendarOpen) {
            return;
        }

        const handleMouseDown = (
            event: MouseEvent
        ): void => {
            const target =
                event.target as Node;

            if (
                wrapperRef.current?.contains(
                    target
                ) ||
                popupRef.current?.contains(
                    target
                )
            ) {
                return;
            }

            setIsCalendarOpen(false);
        };

        document.addEventListener(
            "mousedown",
            handleMouseDown
        );

        return () => {
            document.removeEventListener(
                "mousedown",
                handleMouseDown
            );
        };
    }, [isCalendarOpen]);

    /**
     * Update fieldValue.
     */
    const updateValue = (
        isoDate: string
    ): void => {
        const newData = {
            ...fieldValue,
        };

        if (isoDate) {
            newData[logicalName] = {
                value: isoDate,
            };
        } else {
            delete newData[logicalName];
        }

        setFieldValue(newData);
    };

    /**
     * User gõ ngày.
     */
    const handleInputChange = (
        event: React.ChangeEvent<HTMLInputElement>
    ): void => {
        const text =
            event.target.value;

        setInputValue(text);

        if (!text.trim()) {
            setDate("");
            setInputError("");
            updateValue("");
            return;
        }

        const parsed =
            parseInputDate(
                text,
                format
            );

        if (parsed) {
            setDate(parsed);
            setInputError("");
            updateValue(parsed);

            const parsedDate =
                parseIsoDate(parsed);

            if (parsedDate) {
                setCalendarMonth(
                    new Date(
                        parsedDate.getFullYear(),
                        parsedDate.getMonth(),
                        1
                    )
                );
            }
        } else {
            const digits =
                text.replace(
                    /\D/g,
                    ""
                );

            if (digits.length >= 6) {
                setInputError(
                    "Invalid date"
                );
            } else {
                setInputError("");
            }
        }
    };

    /**
     * Format lại sau khi blur.
     */
    const handleInputBlur = (): void => {
        if (!inputValue.trim()) {
            return;
        }

        const parsed =
            parseInputDate(
                inputValue,
                format
            );

        if (!parsed) {
            setInputError(
                "Invalid date"
            );
            return;
        }

        setDate(parsed);

        setInputValue(
            formatDateValue(
                parsed,
                format
            )
        );

        setInputError("");
    };

    /**
     * Select date từ calendar.
     */
    const handleSelectDate = (
        selectedDate: Date
    ): void => {
        const isoDate =
            toIsoDate(selectedDate);

        setDate(isoDate);

        setInputValue(
            formatDateValue(
                isoDate,
                format
            )
        );

        setInputError("");

        updateValue(isoDate);

        setCalendarMonth(
            new Date(
                selectedDate.getFullYear(),
                selectedDate.getMonth(),
                1
            )
        );

        setIsCalendarOpen(false);
    };

    const handleToday = (): void => {
        handleSelectDate(
            new Date()
        );
    };

    const handlePreviousMonth =
        (): void => {
            setCalendarMonth(
                (current) =>
                    new Date(
                        current.getFullYear(),
                        current.getMonth() - 1,
                        1
                    )
            );
        };

    const handleNextMonth =
        (): void => {
            setCalendarMonth(
                (current) =>
                    new Date(
                        current.getFullYear(),
                        current.getMonth() + 1,
                        1
                    )
            );
        };

    const calendarDays = useMemo(
        () =>
            buildCalendarDays(
                calendarMonth.getFullYear(),
                calendarMonth.getMonth()
            ),
        [calendarMonth]
    );

    const selectedDate =
        parseIsoDate(date);

    const today = new Date();

    const monthTitle =
        calendarMonth.toLocaleDateString(
            undefined,
            {
                month: "long",
                year: "numeric",
            }
        );

    const weekDays = [
        "Sun",
        "Mon",
        "Tue",
        "Wed",
        "Thu",
        "Fri",
        "Sat",
    ];

    const readonlyValue = date
        ? formatDateValue(
            date,
            format
        )
        : "";

    return (
        <div
            className={styles.styleOverField}
            key={logicalName}
        >
            <div
                style={{
                    display: "flex",
                    gap: "2px",
                    flexDirection: "row",
                }}
            >
                {/* LABEL */}
                <div
                    style={{
                        minWidth: 180,
                        display: "flex",
                        gap: "2px",
                        flexDirection: "row",
                    }}
                >
                    <label
                        style={{
                            paddingBlockStart: 2,
                            marginInlineEnd: 4,
                            width: "100%",
                        }}
                    >
                        {label}
                    </label>

                    {isRequired ? (
                        <span
                            style={{
                                color: "red",
                                paddingBlockStart: 2,
                                marginInlineEnd: 2,
                            }}
                        >
                            *
                        </span>
                    ) : (
                        <span
                            style={{
                                color: "white",
                                paddingBlockStart: 2,
                                marginInlineEnd: 2,
                            }}
                        >
                            *
                        </span>
                    )}

                    {isDisable && (
                        <IconLock />
                    )}
                </div>

                {/* FIELD */}
                {!isDisable ? (
                    <div
                        style={{
                            width: "100%",
                        }}
                    >
                        <div
                            ref={wrapperRef}
                            className={
                                styles.wrapper
                            }
                        >
                            <Input
                                type="text"
                                value={
                                    inputValue
                                }
                                placeholder="---"
                                className={
                                    styles.styleInput
                                }
                                onChange={
                                    handleInputChange
                                }
                                onBlur={
                                    handleInputBlur
                                }
                            />

                            <button
                                ref={
                                    calendarButtonRef
                                }
                                type="button"
                                className={
                                    styles.calendarButton
                                }
                                onMouseDown={(
                                    event
                                ) => {
                                    event.preventDefault();
                                }}
                                onClick={
                                    openCalendar
                                }
                                aria-label="Open calendar"
                            >
                                <svg
                                    className={
                                        styles.calendarIcon
                                    }
                                    viewBox="0 0 16 16"
                                    fill="none"
                                >
                                    <path
                                        d="M3.5 2.5V4M12.5 2.5V4M2.5 6H13.5"
                                        stroke="currentColor"
                                        strokeWidth="1"
                                        strokeLinecap="round"
                                    />

                                    <rect
                                        x="2.5"
                                        y="3.5"
                                        width="11"
                                        height="10"
                                        rx="1.5"
                                        stroke="currentColor"
                                        strokeWidth="1"
                                    />

                                    <path
                                        d="M5 8H5.01M8 8H8.01M11 8H11.01M5 10.5H5.01M8 10.5H8.01"
                                        stroke="currentColor"
                                        strokeWidth="1.3"
                                        strokeLinecap="round"
                                    />
                                </svg>
                            </button>
                        </div>

                        {/* POPUP */}
                        {isCalendarOpen && (
                            <div
                                ref={
                                    popupRef
                                }
                                className={
                                    styles.calendarPopup
                                }
                            // style={{
                            //     top: popupPosition.top,
                            //     left: popupPosition.left,
                            // }}
                            >
                                <div
                                    className={
                                        styles.calendarHeader
                                    }
                                >
                                    <button
                                        type="button"
                                        className={
                                            styles.navigationButton
                                        }
                                        onClick={
                                            handlePreviousMonth
                                        }
                                    >
                                        ‹
                                    </button>

                                    <div
                                        className={
                                            styles.monthTitle
                                        }
                                    >
                                        {
                                            monthTitle
                                        }
                                    </div>

                                    <button
                                        type="button"
                                        className={
                                            styles.navigationButton
                                        }
                                        onClick={
                                            handleNextMonth
                                        }
                                    >
                                        ›
                                    </button>
                                </div>

                                <div
                                    className={
                                        styles.weekHeader
                                    }
                                >
                                    {weekDays.map(
                                        (
                                            day
                                        ) => (
                                            <div
                                                key={
                                                    day
                                                }
                                                className={
                                                    styles.weekDay
                                                }
                                            >
                                                {
                                                    day
                                                }
                                            </div>
                                        )
                                    )}
                                </div>

                                <div
                                    className={
                                        styles.daysGrid
                                    }
                                >
                                    {calendarDays.map(
                                        (
                                            item
                                        ) => {
                                            const isSelected =
                                                sameDate(
                                                    item.date,
                                                    selectedDate
                                                );

                                            const isToday =
                                                sameDate(
                                                    item.date,
                                                    today
                                                );

                                            return (
                                                <button
                                                    key={`${item.date.getFullYear()}-${item.date.getMonth()}-${item.date.getDate()}`}
                                                    type="button"
                                                    className={`
                                                        ${styles.dayButton}
                                                        ${!item.currentMonth
                                                            ? styles.otherMonthDay
                                                            : ""
                                                        }
                                                        ${isToday
                                                            ? styles.todayDay
                                                            : ""
                                                        }
                                                        ${isSelected
                                                            ? styles.selectedDay
                                                            : ""
                                                        }
                                                    `}
                                                    onClick={() =>
                                                        handleSelectDate(
                                                            item.date
                                                        )
                                                    }
                                                >
                                                    {
                                                        item
                                                            .date
                                                            .getDate()
                                                    }
                                                </button>
                                            );
                                        }
                                    )}
                                </div>

                                <div
                                    className={
                                        styles.calendarFooter
                                    }
                                >
                                    <button
                                        type="button"
                                        className={
                                            styles.todayButton
                                        }
                                        onClick={
                                            handleToday
                                        }
                                    >
                                        Today
                                    </button>
                                </div>
                            </div>
                        )}

                        {inputError && (
                            <span
                                style={{
                                    color: "red",
                                    fontSize: "12px",
                                }}
                            >
                                {inputError}
                            </span>
                        )}

                        {isValid &&
                            !date &&
                            isRequired &&
                            !inputError && (
                                <span
                                    style={{
                                        color: "red",
                                        fontSize: "12px",
                                    }}
                                >
                                    {label} is required!
                                </span>
                            )}
                    </div>
                ) : (
                    <Input
                        type="text"
                        value={
                            readonlyValue
                        }
                        className={
                            styles.styleInputReadOnly
                        }
                        readOnly
                    />
                )}
            </div>
        </div>
    );
};

export default DateComponent;