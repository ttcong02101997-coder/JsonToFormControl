import React, { useEffect } from 'react'
import { Text, Input, InteractionTag, InteractionTagPrimary, InteractionTagSecondary, makeStyles, Option, TagGroup, Button, Card } from '@fluentui/react-components';
import { FieldComponentProps, jsonLookupControl } from '../ShareLibs/Models';
import { getLookupRecords } from '../ShareLibs/Shared';
import { IconLock } from '../ShareLibs/Icons';

const useStyles = makeStyles({
    customBtn: {
        border: "none",
        backgroundColor: "#ebf5ff",
        ":hover": {
            backgroundColor: "rgb(207, 228, 250)",
        },
        color: "rgb(17, 94, 163)",
        fontSize: "14px",
        height: "90%"
    },
    styleInput: {
        background: "rgba(0, 0, 0, 0.06)",
        width: "100%",
        border: "none",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        borderRadius: "5px",
        color: "rgb(17, 94, 163)",
        fontSize: "14px",
        cursor: "pointer",
    },
    styleInputReadonly: {
        background: "rgba(0, 0, 0, 0.06)",
        width: "100%",
        border: "none",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        borderRadius: "5px",
        color: "rgb(17, 94, 163)",
        fontSize: "14px",
        cursor: "pointer",
        padding: "7px 8px"
    },

    styleInput1: {
        width: "100%",
        border: "none",
        borderRadius: "5px",
        background: "transparent"
    },
    styleOverField: {
        padding: "3px 0"
    },
    overLookup: {
        paddingLeft: "6px"
    },
    divOver: {
        width: "100%",
        position: "relative"
    },
    cardStyles: {
        position: "absolute",
        right: 0,
        left: 0,
        zIndex: 10,
        padding: "5px",
        maxHeight: "250px",
        overflow: "auto",
        height: "fit-content",
        minHeight: "unset",
    },
    optionStyle: {
        "& .fui-Option__checkIcon": {
            display: "none",
        },

        paddingLeft: "12px",
        paddingRight: "12px",
    },

    readonlyField: {
        color: "rgb(17, 94, 163)",
        display: "inline-block",
        padding: "0px 5px 0px 0px",
        borderRadius: "4px",

    },
    styleTextReadonly: {
        textDecoration: "underline",
        cursor: "pointer",
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        padding: "0px 5px"
    }
});

function LookupComponent({ setFieldValue, value, entityName, context, isDisable, isRequired, label, fieldValue, logicalName, lookupRelated, lookupSubNameAttr, isValid }: FieldComponentProps) {
    const styles = useStyles();
    const [_search, _setSearch] = React.useState<string>("");
    const [valueLookup, setValueLookup] = React.useState<jsonLookupControl | undefined>(undefined);
    const [options, setOptions] = React.useState<jsonLookupControl[]>([]);
    const [openCard, setOpenCard] = React.useState<boolean>(false);
    const [keyword, setKeyword] = React.useState<string>("");
    const lookupValue = value && typeof value === "object"
        ? value as jsonLookupControl
        : undefined;

    React.useEffect(() => {
        setValueLookup((currentValue) => {
            if (
                currentValue?.id === lookupValue?.id &&
                currentValue?.name === lookupValue?.name &&
                currentValue?.entityName === lookupValue?.entityName
            ) {
                return currentValue;
            }

            return lookupValue?.id ? lookupValue : undefined;
        });
    }, [lookupValue?.id, lookupValue?.name, lookupValue?.entityName]);

    const updateLookupValue = (newValue: jsonLookupControl | undefined): void => {
        setValueLookup(newValue);

        if (newValue) {
            setFieldValue({
                ...fieldValue,
                [logicalName]: {
                    id: newValue.id,
                    name: newValue.name,
                    entityName: newValue.entityName,
                },
            });
        } else {
            const newData = { ...fieldValue };
            delete newData[logicalName];
            setFieldValue(newData);
        }
    };

    const viewLookup = () => {
        if (valueLookup != undefined) {
            void window.Xrm.Navigation.navigateTo({
                pageType: "entityrecord",
                entityName: valueLookup.entityName,
                entityId: valueLookup.id
            }, {
                target: 2,
                position: 1,
                width: { value: 80, unit: "%" },
                height: { value: 70, unit: "%" }
            });
        }
    }

    const openLookupDialog = async () => {
        const records = await getLookupRecords(context!, entityName!, lookupRelated!, lookupSubNameAttr!, fieldValue, keyword);
        setOptions(records);
        setOpenCard(true);
    };

    const containerRef = React.useRef<HTMLDivElement>(null);

    React.useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            const target = event.target;

            if (
                target instanceof Node &&
                containerRef.current &&
                !containerRef.current.contains(target)
            ) {
                setOpenCard(false);
                setKeyword("");
            }
        };

        document.addEventListener("mousedown", handleClickOutside);

        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);

    const clickChooseLookup = (e: React.MouseEvent<HTMLElement>) => {
        const selectLookup: jsonLookupControl = {
            id: e.currentTarget.dataset.id!,
            name: e.currentTarget.dataset.name!,
            entityName: e.currentTarget.dataset.entityname!,
        };
        updateLookupValue(selectLookup);
        setOpenCard(false);
        setKeyword("");
    }

    return (
        <>
            <div className={styles.styleOverField} key={logicalName}>
                <div style={{ display: "flex", gap: "2px", flexDirection: "row" }}>
                    <div style={{ minWidth: 180, display: "flex", gap: "2px", flexDirection: "row" }}>
                        <label style={{ paddingBlockStart: 2, marginInlineEnd: 4, width: "100%" }}>{label}</label>
                        {isRequired ? <span style={{ color: "red", paddingBlockStart: 2, marginInlineEnd: 2, textShadow: "0 0 black" }}>*</span> : <span style={{ color: "white", paddingBlockStart: 2, marginInlineEnd: 2 }}>*</span>}
                        {isDisable ? <IconLock /> : null}
                    </div>

                    {
                        !isDisable ?

                            <div style={{ width: "100%" }}>
                                <div className={styles.divOver} ref={containerRef}>
                                    {
                                        valueLookup?.id ?
                                            <div className={styles.styleInput} >
                                                <TagGroup className={styles.overLookup}>
                                                    {valueLookup?.id ? (
                                                        <InteractionTag value={valueLookup.id} key={valueLookup.id}>
                                                            <InteractionTagPrimary
                                                                hasSecondaryAction
                                                                className={styles.customBtn}
                                                                onClick={viewLookup}
                                                            >
                                                                <span style={{ textDecoration: "underline" }}>{valueLookup.name}</span>
                                                            </InteractionTagPrimary>
                                                            <InteractionTagSecondary
                                                                onClick={() => {
                                                                    updateLookupValue(undefined);
                                                                }}
                                                                className={styles.customBtn}
                                                                style={{ border: "none" }}
                                                            />
                                                        </InteractionTag>
                                                    )
                                                        : null
                                                    }
                                                </TagGroup>
                                                <Button
                                                    appearance="transparent"
                                                    icon={<svg
                                                        width="16"
                                                        height="16"
                                                        viewBox="0 0 16 16"
                                                        fill="none"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                    >
                                                        <path
                                                            d="M6.75 2.25C4.26472 2.25 2.25 4.26472 2.25 6.75C2.25 9.23528 4.26472 11.25 6.75 11.25C9.23528 11.25 11.25 9.23528 11.25 6.75C11.25 4.26472 9.23528 2.25 6.75 2.25Z"
                                                            stroke="currentColor"
                                                            strokeWidth="1.2"
                                                        />
                                                        <path
                                                            d="M10.25 10.25L13.5 13.5"
                                                            stroke="currentColor"
                                                            strokeWidth="1.2"
                                                            strokeLinecap="round"
                                                        />
                                                    </svg>}
                                                    onClick={() => void openLookupDialog()}
                                                />
                                            </div>
                                            : <div className={styles.styleInput} >
                                                <Input
                                                    className={`${styles.styleInput1}`}
                                                    disabled={isDisable}
                                                    placeholder={`Look up ${entityName}`}
                                                    onClick={() => void openLookupDialog()}
                                                    onChange={(_, data) => setKeyword(data.value)}
                                                    onKeyDown={(e) => {
                                                        if (e.key === "Enter") {
                                                            e.preventDefault();

                                                            void openLookupDialog();
                                                        }
                                                    }}
                                                    value={keyword}
                                                />

                                                <Button
                                                    appearance="transparent"
                                                    icon={<svg
                                                        width="16"
                                                        height="16"
                                                        viewBox="0 0 16 16"
                                                        fill="none"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                    >
                                                        <path
                                                            d="M6.75 2.25C4.26472 2.25 2.25 4.26472 2.25 6.75C2.25 9.23528 4.26472 11.25 6.75 11.25C9.23528 11.25 11.25 9.23528 11.25 6.75C11.25 4.26472 9.23528 2.25 6.75 2.25Z"
                                                            stroke="currentColor"
                                                            strokeWidth="1.2"
                                                        />
                                                        <path
                                                            d="M10.25 10.25L13.5 13.5"
                                                            stroke="currentColor"
                                                            strokeWidth="1.2"
                                                            strokeLinecap="round"
                                                        />
                                                    </svg>}
                                                    onClick={() => void openLookupDialog()}
                                                />
                                            </div>
                                    }
                                    {
                                        openCard ?
                                            <Card className={styles.cardStyles}>
                                                {
                                                    options.map((item: jsonLookupControl) => (
                                                        <div key={`${logicalName}-${item.id}`} style={{ borderBottom: "1px solid #d7d7d7" }}>
                                                            <Option
                                                                className={styles.optionStyle}
                                                                onClick={(e: React.MouseEvent<HTMLElement>) => { clickChooseLookup(e) }}
                                                                data-id={item.id}
                                                                data-name={item.name}
                                                                data-entityname={item.entityName}
                                                                text={item.name}
                                                            >
                                                                <div>
                                                                    <div>{item.name}</div>
                                                                    <span style={{ fontSize: 11, fontStyle: "italic" }}>{item.subName ?? ""}</span>
                                                                </div>
                                                            </Option>
                                                        </div>
                                                    ))
                                                }
                                            </Card> : null
                                    }
                                </div>
                                {
                                    isValid && !valueLookup?.id && isRequired ? <span style={{ color: "red", fontSize: "12px", textShadow: "0 0 black" }}>{label} is required!</span> : null
                                }
                            </div>
                            :
                            <>
                                {
                                    valueLookup ?
                                        <div className={`${styles.styleInputReadonly}`}>
                                            <div
                                                className={`${styles.readonlyField} ${styles.styleTextReadonly}`}
                                                onClick={viewLookup}
                                                title={valueLookup?.name}
                                                onMouseOver={(e) => {
                                                    e.currentTarget.style.background = "rgb(207, 228, 250)";
                                                }}
                                                onMouseOut={(e) => {
                                                    e.currentTarget.style.background = "";
                                                }}
                                            >
                                                {valueLookup?.name}
                                            </div>
                                        </div>
                                        :
                                        null
                                }

                            </>
                    }
                </div>
            </div>
        </>
    )
}
export default LookupComponent