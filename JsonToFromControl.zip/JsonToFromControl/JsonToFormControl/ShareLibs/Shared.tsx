import { IInputs } from "../generated/ManifestTypes";
import {
    fieldValueProps,
    jsonLookupControl,
    jsonRelatedLookup,
} from "./Models";

type DynamicRecord = Record<string, unknown>;

const getStringProperty = (
    record: DynamicRecord,
    propertyName: string
): string => {
    const value = record[propertyName];

    return typeof value === "string" ? value : "";
};

const escapeODataString = (value: string): string => {
    return value.replace(/'/g, "''");
};

const normalizeGuid = (value: string): string => {
    return value.replace(/[{}]/g, "").trim();
};

export const getLookupRecords = async (context: ComponentFramework.Context<IInputs>, entityName: string, lookupRelated: jsonRelatedLookup[], lookupSubNameAttr: string, fieldValue: Record<string, fieldValueProps>, keyword?: string): Promise<jsonLookupControl[]> => {
    const metadataResult: unknown = await context.utils.getEntityMetadata(entityName);

    if (typeof metadataResult !== "object" || metadataResult === null) {
        return [];
    }

    const metadata = metadataResult as DynamicRecord;
    const primaryId = getStringProperty(metadata, "PrimaryIdAttribute");
    const primaryName = getStringProperty(metadata, "PrimaryNameAttribute");

    if (!primaryId || !primaryName) {
        return [];
    }

    const selectFields = new Set<string>();

    selectFields.add(primaryId);
    selectFields.add(primaryName);

    if (lookupSubNameAttr) {
        selectFields.add(lookupSubNameAttr);
    }

    const filters: string[] = [];

    if (lookupRelated) {
        for (const related of lookupRelated) {
            if (!related.byField || !related.targetAttribute) {
                continue;
            }

            const relatedField = fieldValue[related.byField];
            const rawRelatedId = relatedField?.id;

            if (typeof rawRelatedId !== "string" || rawRelatedId.trim() === "") {
                continue;
            }

            const relatedId = normalizeGuid(rawRelatedId);
            if (!relatedId) {
                continue;
            }

            filters.push(`_${related.targetAttribute}_value eq ${relatedId}`);
        }

    }

    if (keyword != "" && keyword?.trim()) {
        const escapedKeyword = keyword.trim().replace(/'/g, "''");

        const keywordFilters: string[] = [
            `contains(${primaryName},'${escapedKeyword}')`,
        ];

        filters.push(`(${keywordFilters.join("")})`);
    }

    let query = `?$select=${Array.from(selectFields).join(",")}` + `&$top=50`;

    if (filters.length > 0) {
        query += `&$filter=${filters.join(" and ")}`;
    }

    const result = await context.webAPI.retrieveMultipleRecords(entityName, query);
    const records = result.entities as unknown as DynamicRecord[];

    return records.map((record) => {
        const idValue = record[primaryId];
        const nameValue = record[primaryName];
        const subNameValue = lookupSubNameAttr ? record[lookupSubNameAttr] : undefined;

        return {
            id: typeof idValue === "string" ? idValue : "",
            name: typeof nameValue === "string" ? nameValue : "",
            entityName,
            subName: typeof subNameValue === "string" ? subNameValue : "",
        };
    });
};