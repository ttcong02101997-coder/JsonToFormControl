import React from "react";
import { Input, makeStyles, tokens } from "@fluentui/react-components";
import { FieldComponentProps } from "../ShareLibs/Models";
import { IconLock } from "../ShareLibs/Icons";

const useStyles = makeStyles({
    root: {
        display: "grid",
        columnGap: "10px",
        gridTemplateColumns: "repeat(2, 1fr)",
        marginBottom: "10px",
        width: "100%",
    },

    styleInput: {
        background: "rgba(0, 0, 0, 0.06)",
        width: "100%",
        border: "none",
        boxSizing: "border-box",

        "& input": {
            paddingRight: "36px",
        },
    },

    styleOverField: {
        padding: "3px 0",
    },

    wrapper: {
        position: "relative",
        width: "100%",
    },

    calendarIcon: {
        position: "absolute",
        right: "10px",
        top: "50%",
        transform: "translateY(-50%)",
        width: "16px",
        height: "16px",
        pointerEvents: "none",
        color: tokens.colorNeutralForeground3,
    },

    styleInputReadOnly: {
        background: "rgba(0, 0, 0, 0.06)",
        width: "100%",
        border: "none",

        ":focus-within::after": {
            borderBottomColor: "#ccc",
        },
    },

    calendarPopup: {
        position: "fixed",
        zIndex: 2147483647,
        width: "320px",
        backgroundColor: tokens.colorNeutralBackground1,
        border: `1px solid ${tokens.colorNeutralStroke2}`,
        borderRadius: "4px",
        boxShadow: tokens.shadow16,
        padding: "12px",
        boxSizing: "border-box",
    },

    calendarHeader: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: "10px",
    },

    monthTitle: {
        fontSize: "14px",
        fontWeight: 600,
    },

    navButton: {
        border: "none",
        background: "transparent",
        width: "28px",
        height: "28px",
        cursor: "pointer",
        borderRadius: "3px",

        ":hover": {
            backgroundColor: tokens.colorNeutralBackground3,
        },
    },

    weekHeader: {
        display: "grid",
        gridTemplateColumns: "repeat(7, 1fr)",
        marginBottom: "4px",
    },

    weekDay: {
        textAlign: "center",
        fontSize: "11px",
        color: tokens.colorNeutralForeground3,
        padding: "4px 0",
    },

    calendarGrid: {
        display: "grid",
        gridTemplateColumns: "repeat(7, 1fr)",
        gap: "2px",
    },

    dayButton: {
        border: "none",
        background: "transparent",
        height: "32px",
        cursor: "pointer",
        borderRadius: "3px",
        fontSize: "12px",

        ":hover": {
            backgroundColor: tokens.colorNeutralBackground3,
        },
    },

    todayButton: {
        fontWeight: 600,
        textDecoration: "underline",
    },

    selectedDay: {
        backgroundColor: tokens.colorBrandBackground,
        color: tokens.colorNeutralForegroundInverted,

        ":hover": {
            backgroundColor: tokens.colorBrandBackgroundHover,
        },
    },

    timeContainer: {
        display: "flex",
        alignItems: "center",
        gap: "6px",
        marginTop: "12px",
        paddingTop: "10px",
        borderTop: `1px solid ${tokens.colorNeutralStroke2}`,
    },

    timeLabel: {
        fontSize: "12px",
        color: tokens.colorNeutralForeground2,
        marginRight: "4px",
    },

    timeInput: {
        width: "60px",
    },

    periodButton: {
        border: `1px solid ${tokens.colorNeutralStroke1}`,
        background: tokens.colorNeutralBackground1,
        height: "32px",
        minWidth: "54px",
        padding: "0 8px",
        borderRadius: "2px",
        cursor: "pointer",
        fontSize: "12px",

        ":hover": {
            backgroundColor: tokens.colorNeutralBackground3,
        },
    },

    footer: {
        display: "flex",
        justifyContent: "flex-end",
        marginTop: "10px",
        paddingTop: "8px",
        borderTop: `1px solid ${tokens.colorNeutralStroke2}`,
    },

    todayAction: {
        border: "none",
        background: "transparent",
        color: tokens.colorBrandForeground1,
        cursor: "pointer",
        fontSize: "12px",
        padding: "4px 8px",

        ":hover": {
            backgroundColor: tokens.colorNeutralBackground3,
        },
    },
});

interface CalendarDay {
    date: Date;
    currentMonth: boolean;
}

/**
 * yyyy-MM-ddTHH:mm
 */
const formatDateTimeValue = (date: Date): string => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");

    return `${year}-${month}-${day}T${hours}:${minutes}`;
};

const parseDateTimeValue = (
    value: string
): Date | null => {
    if (!value) {
        return null;
    }

    const match = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})?$/.exec(value.trim());

    if (!match) {
        return null;
    }

    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);
    const hour = Number(match[4]);
    const minute = Number(match[5]);

    const date = new Date(
        year,
        month - 1,
        day,
        hour,
        minute,
        0,
        0
    );

    if (
        date.getFullYear() !== year ||
        date.getMonth() !== month - 1 ||
        date.getDate() !== day ||
        date.getHours() !== hour ||
        date.getMinutes() !== minute
    ) {
        return null;
    }

    return date;
};

const pad = (value: number): string =>
    String(value).padStart(2, "0");

/**
 * Convert D365 dateFormat into a display format.
 *
 * Supported:
 *
 * dd/MM/yyyy
 * MM/dd/yyyy
 * yyyy/MM/dd
 * dd-MM-yyyy
 * dd/MM/yyyy HH:mm
 * dd/MM/yyyy hh:mm tt
 */
const formatDateByConfig = (
    date: Date,
    dateFormat?: string
): string => {
    let format = dateFormat?.trim();

    if (format === undefined || format === "") {
        format = "dd/MM/yyyy HH:mm";
    }

    const hour24 = date.getHours();
    const hour12 = hour24 % 12 === 0 ? 12 : hour24 % 12;

    const replacements: Record<string, string> = {
        yyyy: String(date.getFullYear()),
        yy: String(date.getFullYear()).slice(-2),

        MM: pad(date.getMonth() + 1),
        M: String(date.getMonth() + 1),

        dd: pad(date.getDate()),
        d: String(date.getDate()),

        HH: pad(hour24),
        H: String(hour24),

        hh: pad(hour12),
        h: String(hour12),

        mm: pad(date.getMinutes()),
        m: String(date.getMinutes()),

        tt: hour24 >= 12 ? "PM" : "AM",
        t: hour24 >= 12 ? "P" : "A",
    };

    return format.replace(
        /yyyy|yy|MM|M|dd|d|HH|H|hh|h|mm|m|tt|t/g,
        token => replacements[token] ?? token
    );
};

/**
 * Parse value according to dateFormat.
 *
 * Example:
 *
 * 13/09/2026 02:30 PM
 * dateFormat = dd/MM/yyyy hh:mm tt
 */
const parseDateByConfig = (
    value: string,
    dateFormat?: string
): Date | null => {
    if (!value) {
        return null;
    }

    const trimmedFormat = dateFormat?.trim();
    const format = trimmedFormat === undefined || trimmedFormat === ""
        ? "dd/MM/yyyy HH:mm"
        : trimmedFormat;

    const tokenRegex: Record<string, string> = {
        yyyy: "(\\d{4})",
        yy: "(\\d{2})",

        MM: "(\\d{1,2})",
        M: "(\\d{1,2})",

        dd: "(\\d{1,2})",
        d: "(\\d{1,2})",

        HH: "(\\d{1,2})",
        H: "(\\d{1,2})",

        hh: "(\\d{1,2})",
        h: "(\\d{1,2})",

        mm: "(\\d{1,2})",
        m: "(\\d{1,2})",

        tt: "(AM|PM|am|pm)",
        t: "(A|P|a|p)",
    };

    const tokens =
        format.match(
            /yyyy|yy|MM|M|dd|d|HH|H|hh|h|mm|m|tt|t/g
        ) ?? [];

    const regex = format.replace(
        /yyyy|yy|MM|M|dd|d|HH|H|hh|h|mm|m|tt|t/g,
        token => tokenRegex[token]
    );

    const match = new RegExp(
        `^${regex}$`
    ).exec(value.trim());

    if (!match) {
        return null;
    }

    let index = 1;

    let year = 0;
    let month = 1;
    let day = 1;
    let hour = 0;
    let minute = 0;

    let is12Hour = false;
    let period: string | undefined;

    tokens.forEach(token => {
        const currentValue = match[index++];

        switch (token) {
            case "yyyy":
                year = Number(currentValue);
                break;

            case "yy":
                year =
                    2000 +
                    Number(currentValue);
                break;

            case "MM":
            case "M":
                month = Number(currentValue);
                break;

            case "dd":
            case "d":
                day = Number(currentValue);
                break;

            case "HH":
            case "H":
                hour = Number(currentValue);
                break;

            case "hh":
            case "h":
                hour = Number(currentValue);
                is12Hour = true;
                break;

            case "mm":
            case "m":
                minute = Number(currentValue);
                break;

            case "tt":
            case "t":
                period =
                    currentValue.toUpperCase();
                break;

            default:
                break;
        }
    });

    if (is12Hour) {
        if (hour < 1 || hour > 12) {
            return null;
        }

        if (period === "PM" || period === "P") {
            hour =
                hour === 12
                    ? 12
                    : hour + 12;
        } else {
            hour =
                hour === 12
                    ? 0
                    : hour;
        }
    }

    if (
        month < 1 ||
        month > 12 ||
        day < 1 ||
        day > 31 ||
        hour < 0 ||
        hour > 23 ||
        minute < 0 ||
        minute > 59
    ) {
        return null;
    }

    const date = new Date(
        year,
        month - 1,
        day,
        hour,
        minute,
        0,
        0
    );

    if (
        date.getFullYear() !== year ||
        date.getMonth() !== month - 1 ||
        date.getDate() !== day ||
        date.getHours() !== hour ||
        date.getMinutes() !== minute
    ) {
        return null;
    }

    return date;
};

const buildCalendarDays = (
    year: number,
    month: number
): CalendarDay[] => {
    const firstDay = new Date(
        year,
        month,
        1
    );

    const firstWeekDay =
        firstDay.getDay();

    const daysInMonth = new Date(
        year,
        month + 1,
        0
    ).getDate();

    const previousMonthDays =
        new Date(
            year,
            month,
            0
        ).getDate();

    const result: CalendarDay[] = [];

    for (
        let i = firstWeekDay - 1;
        i >= 0;
        i--
    ) {
        result.push({
            date: new Date(
                year,
                month - 1,
                previousMonthDays - i
            ),
            currentMonth: false,
        });
    }

    for (
        let day = 1;
        day <= daysInMonth;
        day++
    ) {
        result.push({
            date: new Date(
                year,
                month,
                day
            ),
            currentMonth: true,
        });
    }

    let nextDay = 1;

    while (result.length < 42) {
        result.push({
            date: new Date(
                year,
                month + 1,
                nextDay
            ),
            currentMonth: false,
        });

        nextDay++;
    }

    return result;
};

const isSameDate = (
    first: Date | null,
    second: Date
): boolean => {
    if (!first) {
        return false;
    }

    return (
        first.getFullYear() ===
        second.getFullYear() &&
        first.getMonth() ===
        second.getMonth() &&
        first.getDate() ===
        second.getDate()
    );
};

const DateTimeComponent = ({
    setFieldValue,
    value,
    isDisable,
    isRequired,
    label,
    fieldValue,
    logicalName,
    isValid,
    dateFormat,
}: FieldComponentProps) => {
    const styles = useStyles();

    const wrapperRef =
        React.useRef<HTMLDivElement>(null);

    const popupRef =
        React.useRef<HTMLDivElement>(null);

    const buttonRef =
        React.useRef<HTMLDivElement>(null);

    const [dateTimeValue, setDateTimeValue] =
        React.useState<string>("");

    const [isCalendarOpen, setIsCalendarOpen] =
        React.useState(false);

    const [calendarDate, setCalendarDate] =
        React.useState<Date>(new Date());

    const [hour, setHour] =
        React.useState("00");

    const [minute, setMinute] =
        React.useState("00");

    React.useEffect(() => {
        if (!value) {
            setDateTimeValue("");
            return;
        }

        const parsedDate =
            parseDateTimeValue(
                value as string
            );

        if (!parsedDate) {
            return;
        }

        setDateTimeValue(
            formatDateByConfig(
                parsedDate,
                dateFormat
            )
        );

        setCalendarDate(parsedDate);

        setHour(
            pad(parsedDate.getHours())
        );

        setMinute(
            pad(parsedDate.getMinutes())
        );
    }, [value, dateFormat]);


    React.useEffect(() => {
        if (!isCalendarOpen) {
            return;
        }

        const handleClickOutside = (
            event: MouseEvent
        ) => {
            const target =
                event.target as Node;

            if (
                wrapperRef.current?.contains(
                    target
                ) ||
                popupRef.current?.contains(
                    target
                )
            ) {
                return;
            }

            setIsCalendarOpen(false);
        };

        document.addEventListener(
            "mousedown",
            handleClickOutside
        );

        return () => {
            document.removeEventListener(
                "mousedown",
                handleClickOutside
            );
        };
    }, [isCalendarOpen]);

    const updateValue = (
        date: Date
    ): void => {
        const newValue =
            formatDateTimeValue(date);

        setDateTimeValue(
            formatDateByConfig(
                date,
                dateFormat
            )
        );

        setFieldValue({
            ...fieldValue,
            [logicalName]: {
                value: newValue,
            },
        });
    };

    const openCalendar = (): void => {
        if (isDisable) {
            return;
        }

        const currentDate =
            parseDateByConfig(
                dateTimeValue,
                dateFormat
            ) ??
            parseDateTimeValue(
                value as string
            ) ??
            new Date();

        setCalendarDate(currentDate);

        setHour(
            pad(currentDate.getHours())
        );

        setMinute(
            pad(currentDate.getMinutes())
        );

        setIsCalendarOpen(true);
    };

    const handleInputChange = (
        event: React.ChangeEvent<HTMLInputElement>
    ): void => {
        const newValue =
            event.target.value;

        setDateTimeValue(newValue);

        if (!newValue) {
            const newData = {
                ...fieldValue,
            };

            delete newData[logicalName];

            setFieldValue(newData);

            return;
        }

        const parsedDate =
            parseDateByConfig(
                newValue,
                dateFormat
            );

        if (!parsedDate) {
            return;
        }

        setCalendarDate(parsedDate);

        setHour(
            pad(parsedDate.getHours())
        );

        setMinute(
            pad(parsedDate.getMinutes())
        );

        updateValue(parsedDate);
    };

    const handleDaySelect = (
        date: Date
    ): void => {
        const selectedDate =
            new Date(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                Number(hour),
                Number(minute),
                0,
                0
            );

        setCalendarDate(
            selectedDate
        );

        updateValue(selectedDate);
    };

    const handleTimeChange = (
        type: "hour" | "minute",
        newValue: string
    ): void => {
        let nextHour =
            Number(hour);

        let nextMinute =
            Number(minute);

        if (type === "hour") {
            nextHour = Math.min(
                23,
                Math.max(
                    0,
                    Number(newValue)
                )
            );

            setHour(
                pad(nextHour)
            );
        } else {
            nextMinute = Math.min(
                59,
                Math.max(
                    0,
                    Number(newValue)
                )
            );

            setMinute(
                pad(nextMinute)
            );
        }

        const newDate =
            new Date(
                calendarDate.getFullYear(),
                calendarDate.getMonth(),
                calendarDate.getDate(),
                nextHour,
                nextMinute,
                0,
                0
            );

        updateValue(newDate);
    };

    const togglePeriod = (): void => {
        const currentHour =
            Number(hour);

        const newHour =
            currentHour >= 12
                ? currentHour - 12
                : currentHour + 12;

        const newDate =
            new Date(
                calendarDate.getFullYear(),
                calendarDate.getMonth(),
                calendarDate.getDate(),
                newHour,
                Number(minute),
                0,
                0
            );

        setHour(
            pad(newHour)
        );

        updateValue(newDate);
    };

    const goPreviousMonth = (): void => {
        setCalendarDate(
            new Date(
                calendarDate.getFullYear(),
                calendarDate.getMonth() - 1,
                1,
                Number(hour),
                Number(minute)
            )
        );
    };

    const goNextMonth = (): void => {
        setCalendarDate(
            new Date(
                calendarDate.getFullYear(),
                calendarDate.getMonth() + 1,
                1,
                Number(hour),
                Number(minute)
            )
        );
    };

    const setToday = (): void => {
        const now = new Date();

        setCalendarDate(now);

        setHour(
            pad(now.getHours())
        );

        setMinute(
            pad(now.getMinutes())
        );

        updateValue(now);
    };

    const calendarDays =
        buildCalendarDays(
            calendarDate.getFullYear(),
            calendarDate.getMonth()
        );

    const selectedDate =
        parseDateByConfig(
            dateTimeValue,
            dateFormat
        );

    const is12HourFormat =
        Boolean(
            dateFormat?.includes("hh") ??
            dateFormat?.includes("h")
        ) &&
        Boolean(
            dateFormat?.includes("tt") ??
            dateFormat?.includes("t")
        );

    const displayHour = is12HourFormat
        ? String(
            Number(hour) % 12 === 0 ? 12 : Number(hour) % 12
        ).padStart(2, "0")
        : hour;

    const period =
        Number(hour) >= 12
            ? "PM"
            : "AM";

    return (
        <div
            className={styles.styleOverField}
            key={logicalName}
        >
            <div
                style={{
                    display: "flex",
                    gap: "2px",
                    flexDirection: "row",
                }}
            >
                <div
                    style={{
                        minWidth: 180,
                        display: "flex",
                        gap: "2px",
                        flexDirection: "row",
                    }}
                >
                    <label
                        style={{
                            paddingBlockStart: 2,
                            marginInlineEnd: 4,
                            width: "100%",
                        }}
                    >
                        {label}
                    </label>

                    {isRequired ? (
                        <span
                            style={{
                                color: "red",
                                paddingBlockStart: 2,
                                marginInlineEnd: 2,
                                textShadow:
                                    "0 0 black",
                            }}
                        >
                            *
                        </span>
                    ) : (
                        <span
                            style={{
                                color: "white",
                                paddingBlockStart: 2,
                                marginInlineEnd: 2,
                            }}
                        >
                            *
                        </span>
                    )}

                    {isDisable ? (
                        <IconLock />
                    ) : null}
                </div>

                {!isDisable ? (
                    <div
                        style={{
                            width: "100%",
                        }}
                    >
                        <div
                            className={
                                styles.wrapper
                            }
                            ref={wrapperRef}
                        >
                            <div
                                ref={buttonRef}
                                style={{
                                    width: "100%",
                                }}
                                onClick={
                                    openCalendar
                                }
                            >
                                <Input
                                    type="text"
                                    value={
                                        dateTimeValue
                                    }
                                    disabled={
                                        isDisable
                                    }
                                    placeholder="---"
                                    className={
                                        styles.styleInput
                                    }
                                    onChange={
                                        handleInputChange
                                    }
                                />

                                <svg
                                    className={
                                        styles.calendarIcon
                                    }
                                    viewBox="0 0 16 16"
                                    fill="none"
                                    aria-hidden="true"
                                >
                                    <path
                                        d="M3.5 2.5V4M12.5 2.5V4M2.5 6H13.5"
                                        stroke="currentColor"
                                        strokeWidth="1"
                                        strokeLinecap="round"
                                    />

                                    <rect
                                        x="2.5"
                                        y="3.5"
                                        width="11"
                                        height="10"
                                        rx="1.5"
                                        stroke="currentColor"
                                        strokeWidth="1"
                                    />

                                    <path
                                        d="M5 8H5.01M8 8H8.01M11 8H11.01M5 10.5H5.01M8 10.5H8.01"
                                        stroke="currentColor"
                                        strokeWidth="1.3"
                                        strokeLinecap="round"
                                    />
                                </svg>
                            </div>
                        </div>

                        {isValid &&
                            !value &&
                            isRequired ? (
                            <span
                                style={{
                                    color: "red",
                                    fontSize: "12px",
                                    textShadow:
                                        "0 0 black",
                                }}
                            >
                                {label} is required!
                            </span>
                        ) : null}

                        {isCalendarOpen ? (
                            <div
                                ref={popupRef}
                                className={
                                    styles.calendarPopup
                                }
                            >
                                <div
                                    className={
                                        styles.calendarHeader
                                    }
                                >
                                    <button
                                        type="button"
                                        className={
                                            styles.navButton
                                        }
                                        onClick={
                                            goPreviousMonth
                                        }
                                    >
                                        ‹
                                    </button>

                                    <span
                                        className={
                                            styles.monthTitle
                                        }
                                    >
                                        {calendarDate.toLocaleString(
                                            "en-US",
                                            {
                                                month: "long",
                                                year: "numeric",
                                            }
                                        )}
                                    </span>

                                    <button
                                        type="button"
                                        className={
                                            styles.navButton
                                        }
                                        onClick={
                                            goNextMonth
                                        }
                                    >
                                        ›
                                    </button>
                                </div>

                                <div
                                    className={
                                        styles.weekHeader
                                    }
                                >
                                    {[
                                        "Su",
                                        "Mo",
                                        "Tu",
                                        "We",
                                        "Th",
                                        "Fr",
                                        "Sa",
                                    ].map(
                                        day => (
                                            <div
                                                key={
                                                    day
                                                }
                                                className={
                                                    styles.weekDay
                                                }
                                            >
                                                {
                                                    day
                                                }
                                            </div>
                                        )
                                    )}
                                </div>

                                <div
                                    className={
                                        styles.calendarGrid
                                    }
                                >
                                    {calendarDays.map(
                                        (
                                            item,
                                            index
                                        ) => {
                                            const isSelected =
                                                isSameDate(
                                                    selectedDate,
                                                    item.date
                                                );

                                            const isToday =
                                                isSameDate(
                                                    new Date(),
                                                    item.date
                                                );

                                            return (
                                                <button
                                                    key={`${item.date.getFullYear()}-${item.date.getMonth()}-${item.date.getDate()}-${index}`}
                                                    type="button"
                                                    className={`${styles.dayButton} ${isSelected
                                                        ? styles.selectedDay
                                                        : ""
                                                        } ${isToday
                                                            ? styles.todayButton
                                                            : ""
                                                        }`}
                                                    style={{
                                                        opacity:
                                                            item.currentMonth
                                                                ? 1
                                                                : 0.4,
                                                    }}
                                                    onClick={() =>
                                                        handleDaySelect(
                                                            item.date
                                                        )
                                                    }
                                                >
                                                    {
                                                        item.date.getDate()
                                                    }
                                                </button>
                                            );
                                        }
                                    )}
                                </div>

                                <div
                                    className={
                                        styles.timeContainer
                                    }
                                >
                                    <span
                                        className={
                                            styles.timeLabel
                                        }
                                    >
                                        Time
                                    </span>

                                    <Input
                                        type="number"
                                        min={
                                            is12HourFormat
                                                ? 1
                                                : 0
                                        }
                                        max={
                                            is12HourFormat
                                                ? 12
                                                : 23
                                        }
                                        value={
                                            displayHour
                                        }
                                        className={
                                            styles.timeInput
                                        }
                                        onChange={e => {
                                            let newHour =
                                                Number(
                                                    e
                                                        .target
                                                        .value
                                                );

                                            if (
                                                Number.isNaN(
                                                    newHour
                                                )
                                            ) {
                                                return;
                                            }

                                            newHour =
                                                Math.min(
                                                    is12HourFormat
                                                        ? 12
                                                        : 23,
                                                    Math.max(
                                                        is12HourFormat
                                                            ? 1
                                                            : 0,
                                                        newHour
                                                    )
                                                );

                                            let hour24 =
                                                newHour;

                                            if (
                                                is12HourFormat
                                            ) {
                                                const isPM =
                                                    Number(
                                                        hour
                                                    ) >=
                                                    12;

                                                hour24 =
                                                    isPM
                                                        ? newHour ===
                                                            12
                                                            ? 12
                                                            : newHour +
                                                            12
                                                        : newHour ===
                                                            12
                                                            ? 0
                                                            : newHour;
                                            }

                                            const newDate =
                                                new Date(
                                                    calendarDate.getFullYear(),
                                                    calendarDate.getMonth(),
                                                    calendarDate.getDate(),
                                                    hour24,
                                                    Number(
                                                        minute
                                                    ),
                                                    0,
                                                    0
                                                );

                                            setHour(
                                                pad(
                                                    hour24
                                                )
                                            );

                                            updateValue(
                                                newDate
                                            );
                                        }}
                                    />

                                    <span>
                                        :
                                    </span>

                                    <Input
                                        type="number"
                                        min={0}
                                        max={59}
                                        value={
                                            minute
                                        }
                                        className={
                                            styles.timeInput
                                        }
                                        onChange={e => {
                                            const newMinute =
                                                Math.min(
                                                    59,
                                                    Math.max(
                                                        0,
                                                        Number(
                                                            e
                                                                .target
                                                                .value
                                                        )
                                                    )
                                                );

                                            const newDate =
                                                new Date(
                                                    calendarDate.getFullYear(),
                                                    calendarDate.getMonth(),
                                                    calendarDate.getDate(),
                                                    Number(
                                                        hour
                                                    ),
                                                    newMinute,
                                                    0,
                                                    0
                                                );

                                            setMinute(
                                                pad(
                                                    newMinute
                                                )
                                            );

                                            updateValue(
                                                newDate
                                            );
                                        }}
                                    />

                                    {is12HourFormat ? (
                                        <button
                                            type="button"
                                            className={
                                                styles.periodButton
                                            }
                                            onClick={
                                                togglePeriod
                                            }
                                        >
                                            {
                                                period
                                            }
                                        </button>
                                    ) : null}
                                </div>

                                <div
                                    className={
                                        styles.footer
                                    }
                                >
                                    <button
                                        type="button"
                                        className={
                                            styles.todayAction
                                        }
                                        onClick={
                                            setToday
                                        }
                                    >
                                        Today
                                    </button>
                                </div>
                            </div>
                        ) : null}
                    </div>
                ) : (
                    <Input
                        type="text"
                        value={
                            value
                                ? (() => {
                                    const date =
                                        parseDateTimeValue(
                                            value as string
                                        );

                                    return date
                                        ? formatDateByConfig(
                                            date,
                                            dateFormat
                                        )
                                        : "";
                                })()
                                : ""
                        }
                        className={
                            styles.styleInputReadOnly
                        }
                        readOnly
                    />
                )}
            </div>
        </div>
    );
};

export default DateTimeComponent;