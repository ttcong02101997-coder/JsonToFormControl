import { IInputs } from "../generated/ManifestTypes";

export interface jsonFormControl {
    formLogicalName: string;
    sectionBox: boolean;
    sections: jsonFormSection[];
}

export interface jsonFormSection {
    sectionLogicalName: string;
    sectionLabel: string;
    showLabel: boolean;
    sectionControls: Record<string, jsonControl[]>;
}

export interface jsonControl {
    logicalName: string;
    displayName: string;
    type: string;
    lookupEntity: string;
    lookupRelated: jsonRelatedLookup[];
    lookupSubNameAttr: string;
    items: jsonOptionsetControl[];
    required: boolean;
}

export interface jsonOptionsetControl {
    value: number;
    label: string;
}

export interface jsonLookupControl {
    id: string;
    name: string;
    entityName: string;
    subName?: string;
}

export interface FieldComponentProps {
    key: string;
    value: string | number | boolean | undefined | fieldValueProps;
    label: string;
    setFieldValue: (value: Record<string, fieldValueProps>) => void;
    isDisable: boolean;
    isRequired: boolean;
    entityName?: string;
    options?: jsonOptionsetControl[];
    context?: ComponentFramework.Context<IInputs>;
    logicalName: string;
    lookupRelated?: jsonRelatedLookup[];
    lookupSubNameAttr?: string;
    fieldValue: Record<string, fieldValueProps>;
    isValid: boolean;
}

export interface fieldValueProps {
    value?: string | number | boolean;
    id?: string;
    name?: string;
    entityName?: string;
    label?: string;
}

export type InputType =
    | "number"
    | "time"
    | "text"
    | "search"
    | "email"
    | "password"
    | "tel"
    | "url"
    | "date"
    | "datetime-local"
    | "month"
    | "week";

export interface jsonRelatedLookup {
    byField: string;
    targetAttribute: string;
}