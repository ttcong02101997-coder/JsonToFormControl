import React from 'react'
import { IInputs } from '../generated/ManifestTypes';
import { Card, FluentProvider, makeStyles, webLightTheme } from '@fluentui/react-components';
import { useEffect, useState } from 'react';
import { fieldValueProps, jsonControl, jsonFormControl, jsonFormSection } from '../ShareLibs/Models';
import RenderFieldComponent from './RenderFieldComponent';

export interface FormComponentProps {
    context: ComponentFramework.Context<IInputs>;
    fieldProperty: string;
    jsonProperty: string;
    callback: (e: string) => void;
}

const useStyles = makeStyles({
    overColumnStyle: {
        flexWrap: "wrap",
        display: "grid",
        gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
        gap: "16px",
        width: "100%",
        boxSizing: "border-box",

        "@media (max-width: 1024px)": {
            gridTemplateColumns: "repeat(2, minmax(0, 1fr)) !important",
        },

        "@media (max-width: 786px)": {
            gridTemplateColumns: "1fr !important",
        },
    },
    columnStyle: {
        padding: 0,
        boxShadow: "none",
        minWidth: 0,
        width: "100%",
        boxSizing: "border-box",
    },
    sectionCard: {
        padding: 0,
        margin: 0,
        boxShadow: "none"
    }
})

function FormComponent({ context, fieldProperty, jsonProperty, callback }: FormComponentProps) {
    const styles = useStyles();
    const [dataJson, setDataJson] = useState<jsonFormControl | null>(null);
    const [fieldValue, setFieldValue] = useState<Record<string, fieldValueProps>>({});
    const [isValid, setIsValid] = useState<boolean>(true);
    const isDisabled = context.mode.isControlDisabled;

    useEffect(() => {
        const formContext = window.parent.Xrm?.Page;

        if (!formContext) {
            return;
        }

        const hasFieldValue = (field: jsonControl): boolean => {
            const currentValue = fieldValue[field.logicalName];

            if (!currentValue) {
                return false;
            }

            if (field.type === "lookup") {
                return Boolean(currentValue.id);
            }

            if (field.type === "boolean") {
                return typeof currentValue.value === "boolean";
            }

            if (field.type === "optionset") {
                return currentValue.value !== undefined && currentValue.value !== null && currentValue.value !== -1;
            }

            return currentValue.value !== undefined && currentValue.value !== null && currentValue.value !== "";
        };

        const handleFormSave = (executionContext: Xrm.Events.SaveEventContext): void => {
            const eventArgs = executionContext.getEventArgs();
            const hasMissingRequiredField = dataJson?.sections.some((section: jsonFormSection) =>
                Object.values(section.sectionControls).some((fields: jsonControl[]) =>
                    fields.some((field: jsonControl) => field.required && !hasFieldValue(field))
                )
            ) ?? false;

            setIsValid(hasMissingRequiredField);

            if (hasMissingRequiredField) {
                eventArgs.preventDefault();

                formContext.ui.setFormNotification(
                    "Vui lòng nhập đầy đủ thông tin bắt buộc.",
                    "ERROR",
                    "PCF_VALIDATION"
                );

                return;
            }
            else {
                formContext.ui.clearFormNotification("PCF_VALIDATION");
            }
        };

        formContext.data.entity.addOnSave(handleFormSave);

        return () => {
            formContext.data.entity.removeOnSave(handleFormSave);
        };
    }, [dataJson, fieldValue]);

    useEffect(() => {
        if (fieldProperty && fieldProperty !== 'val') {
            try {
                const parsed: unknown = JSON.parse(fieldProperty);
                setFieldValue(parsed as Record<string, fieldValueProps>);
            } catch {
                setFieldValue({});
            }
        }
    }, [fieldProperty]);

    useEffect(() => {
        if (fieldProperty && fieldProperty !== 'val') {
            try {
                const parsed: unknown = JSON.parse(jsonProperty);

                setDataJson(parsed as jsonFormControl);
            } catch {
                setDataJson(null);
            }
        }
    }, [jsonProperty]);

    useEffect(() => {
        callback(JSON.stringify(fieldValue));
    }, [fieldValue])

    return (
        <FluentProvider theme={webLightTheme} style={{ width: "100%" }}>
            {
                dataJson ? (
                    <div id={dataJson.formLogicalName}>
                        {dataJson.sections.map((section: jsonFormSection) => {
                            const columns = Object.keys(section.sectionControls);
                            const columnCount = Math.min(columns.length, 3);
                            return (
                                <Card key={`${section.sectionLogicalName}`} className={dataJson.sectionBox ? styles.sectionCard : ""}>
                                    {
                                        section.showLabel ? <div style={{ fontWeight: 600, textTransform: "uppercase" }}>{section.sectionLabel}</div> : null
                                    }
                                    <div className={styles.overColumnStyle} style={{
                                        gridTemplateColumns: `repeat(${columnCount}, minmax(0, 1fr))`,
                                    }}>
                                        {
                                            Object.keys(section.sectionControls).map((column: string) => (
                                                <Card className={styles.columnStyle} key={`${section.sectionLogicalName}-${column}`}>
                                                    {
                                                        section.sectionControls[column]?.map((field: jsonControl) => {
                                                            return (
                                                                <RenderFieldComponent
                                                                    key={field.logicalName}
                                                                    context={context}
                                                                    isDisable={isDisabled}
                                                                    objControl={field}
                                                                    fieldValue={fieldValue}
                                                                    setFieldValue={(e: Record<string, fieldValueProps>) => setFieldValue(e)}
                                                                    isValid={isValid}
                                                                />
                                                            )
                                                        })
                                                    }
                                                </Card>
                                            ))
                                        }
                                    </div>
                                </Card>
                            )
                        })}
                    </div>
                ) : null
            }
        </FluentProvider>
    )
}

export default FormComponent