import { Input, makeStyles } from '@fluentui/react-components'
import React from 'react'
import { FieldComponentProps } from '../ShareLibs/Models';

const useStyles = makeStyles({
    styleInput: {
        background: "rgba(0, 0, 0, 0.06)",
        width: "100%",
        border: "none"
    },
    styleOverField: {
        padding: "3px 0"
    },
})


function NumberComponent({ setFieldValue, value, isDisable, isRequired, label, fieldValue, logicalName, isValid }: FieldComponentProps) {
    const styles = useStyles();
    const [data, setData] = React.useState<string>(value as string ?? "");

    React.useEffect(() => {
        setData(value as string ?? "");
    }, [value])

    React.useEffect(() => {
        if (data) {
            setFieldValue({
                ...fieldValue,
                [logicalName]: {
                    value: data
                }
            });
        }
        else {
            const newData = { ...fieldValue };
            delete newData[logicalName];

            setFieldValue(newData);
        }
    }, [data])

    return (
        <div className={styles.styleOverField} key={logicalName}>
            <div style={{ display: "flex", gap: "2px", flexDirection: "row" }}>
                <div style={{ minWidth: 180, display: "flex", gap: "2px", flexDirection: "row" }}>
                    <label style={{ paddingBlockStart: 2, marginInlineEnd: 4 }}>{label}</label>
                    {isRequired ? <span style={{ color: "red", paddingBlockStart: 2, marginInlineEnd: 2, textShadow: "0 0 black" }}>*</span> : <span style={{ color: "white", paddingBlockStart: 2, marginInlineEnd: 2 }}>*</span>}
                </div>
                {
                    !isDisable ?
                        <div style={{ width: "100%" }}>
                            <Input type={"number"} value={data} onChange={(_, data) => setData(data.value)} className={styles.styleInput} placeholder={`---`} />
                            {
                                isValid && !value && isRequired ? <span style={{ color: "red", fontSize: "12px", textShadow: "0 0 black" }}>{label} is required!</span> : null
                            }
                        </div>
                        :
                        <Input type={"number"} value={data} className={styles.styleInput} disabled />
                }
            </div>
        </div>
    )
}

export default NumberComponent