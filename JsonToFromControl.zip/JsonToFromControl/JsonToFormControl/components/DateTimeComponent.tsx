import React from "react";
import { Input, makeStyles, tokens } from "@fluentui/react-components";
import { FieldComponentProps } from "../ShareLibs/Models";

const useStyles = makeStyles({
    root: {
        display: "grid",
        columnGap: "10px",
        gridTemplateColumns: "repeat(2, 1fr)",
        marginBottom: "10px",
        width: "100%",
    },

    styleInput: {
        background: "rgba(0, 0, 0, 0.06)",
        width: "100%",
        border: "none",
        boxSizing: "border-box",

        "& input": {
            paddingRight: "36px",
        },

        "& input::-webkit-calendar-picker-indicator": {
            opacity: 0,
            cursor: "pointer",
            position: "absolute",
            right: "0",
            width: "36px",
            height: "100%",
        },
    },

    styleOverField: {
        padding: "3px 0",
    },

    wrapper: {
        position: "relative",
        width: "100%",
    },

    calendarIcon: {
        position: "absolute",
        right: "10px",
        top: "50%",
        transform: "translateY(-50%)",
        width: "16px",
        height: "16px",
        pointerEvents: "none",
        color: tokens.colorNeutralForeground3,
    },
});

const formatDateTime = (date: Date): string => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");

    return `${year}-${month}-${day}T${hours}:${minutes}`;
};

const DateTimeComponent = ({ setFieldValue, value, isDisable, isRequired, label, fieldValue, logicalName, isValid }: FieldComponentProps) => {
    const styles = useStyles();

    const [dateTimeValue, setDateTimeValue] = React.useState<string>("");

    React.useEffect(() => {
        if (!value) {
            setDateTimeValue("");
            return;
        }

        const dateValue = new Date(value as string);

        if (Number.isNaN(dateValue.getTime())) {
            setDateTimeValue("");
            return;
        }

        setDateTimeValue(formatDateTime(dateValue));
    }, [value]);

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>): void => {
        const newValue = event.target.value;
        setDateTimeValue(newValue);

        if (newValue) {
            setFieldValue({
                ...fieldValue,
                [logicalName]: {
                    value: newValue,
                },
            });
        } else {
            const newData = { ...fieldValue };
            delete newData[logicalName];
            setFieldValue(newData);
        }
    };

    return (
        <div className={styles.styleOverField} key={logicalName}>
            <div
                style={{
                    display: "flex",
                    gap: "2px",
                    flexDirection: "row",
                }}
            >
                <div
                    style={{
                        minWidth: 180,
                        display: "flex",
                        gap: "2px",
                        flexDirection: "row",
                    }}
                >
                    <label
                        style={{
                            paddingBlockStart: 2,
                            marginInlineEnd: 4,
                        }}
                    >
                        {label}
                    </label>

                    {isRequired ? (
                        <span
                            style={{
                                color: "red",
                                paddingBlockStart: 2,
                                marginInlineEnd: 2,
                                textShadow: "0 0 black"
                            }}
                        >
                            *
                        </span>
                    ) : (
                        <span
                            style={{
                                color: "white",
                                paddingBlockStart: 2,
                                marginInlineEnd: 2,
                            }}
                        >
                            *
                        </span>
                    )}
                </div>

                {!isDisable ? (
                    <div style={{ width: "100%" }}>
                        <div className={styles.wrapper}>
                            <div className={styles.wrapper}>
                                <Input
                                    type="datetime-local"
                                    value={dateTimeValue}
                                    disabled={isDisable}
                                    placeholder="---"
                                    className={styles.styleInput}
                                    onChange={handleChange}
                                />

                                <svg
                                    className={styles.calendarIcon}
                                    viewBox="0 0 16 16"
                                    fill="none"
                                    aria-hidden="true"
                                >
                                    <path
                                        d="M3.5 2.5V4M12.5 2.5V4M2.5 6H13.5"
                                        stroke="currentColor"
                                        strokeWidth="1"
                                        strokeLinecap="round"
                                    />
                                    <rect
                                        x="2.5"
                                        y="3.5"
                                        width="11"
                                        height="10"
                                        rx="1.5"
                                        stroke="currentColor"
                                        strokeWidth="1"
                                    />
                                    <path
                                        d="M5 8H5.01M8 8H8.01M11 8H11.01M5 10.5H5.01M8 10.5H8.01"
                                        stroke="currentColor"
                                        strokeWidth="1.3"
                                        strokeLinecap="round"
                                    />
                                </svg>
                            </div>
                        </div> {
                            isValid && !value && isRequired ? <span style={{ color: "red", fontSize: "12px", textShadow: "0 0 black" }}>{label} is required!</span> : null
                        }
                    </div>
                ) : (
                    <Input
                        type="text"
                        value={value as string}
                        className={styles.styleInput}
                        disabled
                    />
                )}
            </div>
        </div>
    );
};

export default DateTimeComponent;